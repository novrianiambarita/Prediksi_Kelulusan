import pickle
from flask import Flask, request, render_template
from datetime import datetime
import pandas as pd
from sklearn.preprocessing import StandardScaler

app = Flask(__name__)

# Load model dan feature yang dipilih
model = pickle.load(open("logistic_model.pkl", "rb"))
selected_features = pickle.load(open("selected_features.pkl", "rb"))
scaler = pickle.load(open("scaler.pkl", "rb"))

# Menyimpan riwayat prediksi sementara
riwayat_data = []

# --------- Fungsi Encode Input ---------
def encode_input(data):
    jurusan_dict = {
        "jurusan_Akuntansi": 0,
        "jurusan_Manajemen": 0,
        "jurusan_Sistem Informasi": 0,
        "jurusan_Teknik Informatika": 0,
    }
    jurusan_key = f"jurusan_{data['jurusan']}"
    if jurusan_key in jurusan_dict:
        jurusan_dict[jurusan_key] = 1

    input_dict = {
        "ipk": float(data["ipk"]),
        "sks": int(data["sks"]),
        "kehadiran": int(data["kehadiran"]),
        "tidak_lulus": int(data["tidak_lulus"]),
        "organisasi": int(data["organisasi"]),
        "semester": int(data["semester"]),
        **jurusan_dict,
    }

    df_input = pd.DataFrame([input_dict])
    df_selected = df_input[selected_features]
    df_scaled = scaler.transform(df_selected)
    return df_scaled, input_dict

# --------- Validasi Syarat Kelulusan ---------
def cek_syarat_manual(data):
    try:
        ipk = float(data['ipk'])
        sks = int(data['sks'])
        semester = int(data['semester'])
        kehadiran = int(data['kehadiran'])
        tidak_lulus = int(data['tidak_lulus'])

        if (
            ipk >= 3 and
            sks >= 144 and
            7 <= semester <= 14 and
            kehadiran >= 85 and
            tidak_lulus == 0
        ):
            return True
        return False
    except:
        return False

# --------- Halaman Utama ---------
@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

# --------- Proses Prediksi ---------
@app.route("/predict", methods=["POST"])
def predict():
    try:
        input_data = request.form.to_dict()
        memenuhi_syarat = cek_syarat_manual(input_data)

        final_input, input_dict = encode_input(input_data)
        hasil_prediksi = model.predict(final_input)[0]

        # Penentuan hasil akhir dengan kombinasi prediksi dan syarat manual
        if hasil_prediksi == 1 and memenuhi_syarat:
            hasil = "Lulus"
        elif hasil_prediksi == 1 and not memenuhi_syarat:
            hasil = "Tidak Lulus (Tidak Memenuhi Syarat)"
        else:
            hasil = "Tidak Lulus"

        input_dict["hasil"] = hasil
        input_dict["waktu"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        riwayat_data.append(input_dict)

        return render_template("index.html", result=hasil, input=input_dict)
    except Exception as e:
        return render_template("index.html", result=f"❌ Error: {str(e)}")

# --------- Halaman Riwayat ---------
@app.route("/riwayat", methods=["GET"])
def riwayat():
    return render_template("riwayat.html", riwayat=riwayat_data)

# --------- Menjalankan Aplikasi ---------
if __name__ == "__main__":
    app.run(debug=True)